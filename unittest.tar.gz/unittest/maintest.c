/**************************************************************************************************/
/* Copyright (C) SA14226202@USTC, 2014-2015                                                       */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                              */
/*  PRINCIPAL AUTHOR      :  Guoqing Zuo                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  utest                                                                */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  utest of menu interfac                                               */
/**************************************************************************************************/

/*
 *	Revision log
 *  
 *  Created by  Guoqing Zuo, 2014/09/30
 *
 */
 
 #include "menu.h"
 #include "utest.h"
 
 int main()
 {
    /*test case for method InitMenu()*/
    TestInitMenu();

    /*test case for method StartMenu()*/
    TestStartMenu();

    /*test case for method ShowCmdList()*/
    TestShowCmdList();

    /*test case for method FindMenuCmd()*/
    TestFindMenuCmd();

    /*test case for method CreatCmd()*/
    TestCreatCmd();

    /*test case for method AddCmd()*/
    TestCreatCmd();

    /*test case for method DelCmd()*/
    TestDelCmd();

    /*test case for method DelCmdMenu()*/
    TestDelCmdMenu();
    
    return 0;
 }
 
 
