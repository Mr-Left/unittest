/**************************************************************************************************/
/* Copyright (C) SA14226202@USTC, 2014-2015                                                       */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Guoqing Zuo                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  Definition of menu                                                   */
/**************************************************************************************************/

/*
 *	Revision log
 *  
 *  Modified by Guoqing Zuo, 2014/09/30
 *
 *  Modified by Guoqing zuo, 2014/09/23
 *
 *	Created by Guoqing Zuo, 2014/09/20
 *
 */

#include "menu.h"

/*Cmd handler method*/
int Help()
{
    return 0;
}

int Quit()
{
    exit(0);
    return 0;
}

/*Method to initialize linklist*/
void InitMenu(tLinkTable** pLink)
{
    ;
}

void StartMenu(tLinkTable* pLink)
{
    ;
}   

/*Method to show all cmd list member*/
int ShowCmdList(const tLinkTable* pLink)
{
    if(pLink == NULL)
    {
        return 0;
    }
    
    return 1;
}

/*Method to find weather there is a cmd like input*/
tLinkTableNode* FindMenuCmd(const tLinkTable* pLink, const char* cmd)
{
	return NULL;
}

/*Method to creat a new help command*/
tLinkTableNode* CreatCmd(char* cmd, char* des, int (*handler)())
{
    return NULL;
}

/*Method to add new command to command list*/
int AddCmd(tLinkTable* pLink, tLinkTableNode* pNode)
{
    if(pLink == NULL || pNode == NULL)
    {
        return FAILURE;
    }
    
    return SUCCESS;
}

/*Method to delete a command from command list*/
int DelCmd(tLinkTable* pLink, const char* cmd)
{
    if(pLink == NULL || pLink->head == NULL)
    {
        return FAILURE;
    }
    
    return SUCCESS;
}

/*Method to delete command menu*/
int DelCmdMenu(tLinkTable** pLink)
{
    if(pLink == NULL || *pLink == NULL)
    {
        return FAILURE;
    }
    
    return SUCCESS;
}


