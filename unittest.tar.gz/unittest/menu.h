/**************************************************************************************************/
/* Copyright (C) SA14226202@USTC, 2014-2015                                                       */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Guoqing Zuo                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  utest                                                                */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 *	Revision log
 *  
 *  Created by  Guoqing Zuo, 2014/09/30
 *
 */
 
#ifndef _MENU_H_
#define _MENU_H_

#include <stdlib.h>

#include "linktable.h"

#define SUCCESS 1
#define FAILURE 0

/*Method to initialize pLinklist*/
void InitMenu(tLinkTable** pLink);

/*Method to start menu program*/
void StartMenu(tLinkTable* pLink);

/*Method to show all cmd list member*/
int ShowCmdList(const tLinkTable* pLink);

/*Method to find weather there is a cmd like input*/
tLinkTableNode* FindMenuCmd(const tLinkTable* pLink, const char* cmd);

/*Method to creat a new help command*/
tLinkTableNode* CreatCmd(char* cmd, char* des, int (*handler)());

/*Method to add new command to command list*/
int AddCmd(tLinkTable* pLink, tLinkTableNode* pNode);

/*Method to delete a command from command list*/
int DelCmd(tLinkTable* pLink, const char* cmd);

/*Method to delete command menu*/
int DelCmdMenu(tLinkTable** pLink);

#endif

