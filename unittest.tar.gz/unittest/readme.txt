#This is a unit test of menu.h

#You can use the following step to test it:
    $ gcc menu.c utest.c maintest.c -o test
    $ ./test
