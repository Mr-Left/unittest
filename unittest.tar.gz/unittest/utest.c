/**************************************************************************************************/
/* Copyright (C) SA14226202@USTC, 2014-2015                                                       */
/*                                                                                                */
/*  FILE NAME             :  utest.c                                                              */
/*  PRINCIPAL AUTHOR      :  Guoqing Zuo                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  utest                                                                */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  utest of menu interfac                                               */
/**************************************************************************************************/

/*
 *	Revision log
 *  
 *  Created by  Guoqing Zuo, 2014/09/30
 *
 */

#include "utest.h"

/*test case for method InitMenu()*/
void TestInitMenu()
{
    tLinkTable* head = NULL;
    InitMenu(&head);
    if(head == NULL)
    {
        puts("ERROR: Some errors occur in method InitMenu()\n");
    }
    else
    {
        puts("Method InitMenu() is ok!\n");
    }
}

/*test case for method StartMenu()*/
void TestStartMenu()
{
    tLinkTable* pLink = NULL;
    StartMenu(pLink);
}

/*test case for method ShowCmdList()*/
void TestShowCmdList()
{
    tLinkTable* pLink = NULL;
    int result = ShowCmdList(pLink);
    if(result == SUCCESS)
    {
        puts("Method of ShowCmdList() is ok!\n");
    }
    else
    {
        puts("ERROR: Some errors occur in method ShowCmdList()\n");
    }
}

/*test case for method FindMenuCmd()*/
void TestFindMenuCmd()
{
    tLinkTable* pLink = NULL;
    char* cmd = NULL;

    tLinkTableNode* pNode = FindMenuCmd(pLink, cmd);
    if(pNode == NULL)
    {
        puts("ERROR: Some errors occur in method FindMenuCmd()\n");
    }
    else
    {
        puts("Method FindMenuCmd() works ok!\n");
    }
}

/*test case for method CreatCmd()*/
void TestCreatCmd()
{
    char* cmd = NULL;
    char* des = NULL;
    int (*handler)() = NULL;
    
    tLinkTableNode* pNode = CreatCmd(cmd, des, handler);
    if(pNode == NULL)
    {
        puts("ERROR: Some errors occur in method CreatCmd()\n");
    }
    else
    {
        puts("Method CreatCmd() works ok!\n");
    }
}

/*test case for method AddCmd()*/
void TestAddCmd()
{
    tLinkTable* pLink = NULL;
    tLinkTableNode* pNode = NULL;
    
    int result = AddCmd(pLink, pNode);
    if(result == SUCCESS)
    {
        puts("Method of AddCmd() is ok!\n");
    }
    else
    {
        puts("ERROR: Some errors occur in method AddCmd()\n");
    }
}

/*test case for method DelCmd()*/
void TestDelCmd()
{
    tLinkTable* pLink = NULL;
    char* cmd = NULL;
    
    int result = DelCmd(pLink, cmd);
    if(result == SUCCESS)
    {
        puts("Method of DelCmd() is ok!\n");
    }
    else
    {
        puts("ERROR: Some errors occur in method DelCmd()\n");
    }
}

/*test case for method DelCmdMenu()*/
void TestDelCmdMenu()
{
    tLinkTable* pLink = NULL;
    
    int result = DelCmdMenu(&pLink);
    if(result == SUCCESS)
    {
        puts("Method of DelCmdMenu() is ok!\n");
    }
    else
    {
        puts("ERROR: Some errors occur in method DelCmdMenu()\n");
    }
}


