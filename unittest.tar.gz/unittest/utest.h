/**************************************************************************************************/
/* Copyright (C) SA14226202@USTC, 2014-2015                                                       */
/*                                                                                                */
/*  FILE NAME             :  utest.h                                                              */
/*  PRINCIPAL AUTHOR      :  Guoqing Zuo                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  utest                                                                */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  interface of utest                                                   */
/**************************************************************************************************/

/*
 *	Revision log
 *  
 *  Created by  Guoqing Zuo, 2014/09/30
 *
 */

#ifndef _UTEST_H_
#define _UTEST_H_

#include <stdio.h>
#include "menu.h"

/*test case for method InitMenu()*/
void TestInitMenu();

/*test case for method StartMenu()*/
void TestStartMenu();

/*test case for method ShowCmdList()*/
void TestShowCmdList();

/*test case for method FindMenuCmd()*/
void TestFindMenuCmd();

/*test case for method CreatCmd()*/
void TestCreatCmd();

/*test case for method AddCmd()*/
void TestAddCmd();

/*test case for method DelCmd()*/
void TestDelCmd();

/*test case for method DelCmdMenu()*/
void TestDelCmdMenu();

#endif
